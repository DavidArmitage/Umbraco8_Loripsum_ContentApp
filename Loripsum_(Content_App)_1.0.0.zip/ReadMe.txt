-------------------------------------
CONFIGURATION INSTRUCTIONS
-------------------------------------

NO CONFIGURATION REQUIRED
-------------------------------------
This app should work out of the box and no extra configuration is required.


PLEASE SHOW YOUR APPRECIATION
-------------------------------------
If you like this content app then please feel free to show your appreciation by voting and leaving comments here.
https://our.umbraco.com/packages/backoffice-extensions/loripsum-content-app/



WHERE TO REPORT ISSUES
-------------------------------------
You can either drop me an email at david@recsitedesign.com or you can log a issue at the following URL.
https://github.com/DavidArmitage/Umbraco8_Loripsum_ContentApp/issues


LATEST VERSION
-------------------------------------
The latest version of the app can be found here
https://github.com/DavidArmitage/Umbraco8_Loripsum_ContentApp


