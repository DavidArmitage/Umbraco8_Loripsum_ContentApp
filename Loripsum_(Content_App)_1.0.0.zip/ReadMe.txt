-----------------------------------------------
Umbraco8 Loripsum ContentApp
-----------------------------------------------
This is a content app to assist developer with creating dummy test content. It's very time consuming opening Loripsum websites and it also takes up valuable tab space. I have managed to build an app within Umbraco which quickly allows you to spin up test content. I'm hoping this will save you devs a load of time. 
The app is designed for developers so it's only activated for administrator users. This is however configurable in the package.manifest file. See documentation for further details.

-------------------------------------
CONFIGURATION INSTRUCTIONS
-------------------------------------

NO CONFIGURATION REQUIRED
-------------------------------------
This app should work out of the box and no extra configuration is required.


PLEASE SUPPORT THIS APP MY UP VOTING 
-------------------------------------
If you like this content app then please feel free to show your appreciation by voting.


WHERE TO REPORT ISSUES
-------------------------------------
You can either drop me an email at david@recsitedesign.com or you can log a issue at the following URL.
https://github.com/DavidArmitage/Umbraco8_Loripsum_ContentApp/issues


LATEST VERSION
-------------------------------------
The latest version of the app can be found here
https://github.com/DavidArmitage/Umbraco8_Loripsum_ContentApp


