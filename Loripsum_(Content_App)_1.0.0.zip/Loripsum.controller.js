﻿
angular.module("umbraco")
    .controller("My.Loripsum", function ($http, $scope, $sce) {

        var vm = this;
        vm.Loading = false;

        var clipboard = new ClipboardJS('#Loripsum_CopyToClipboard');

        //default settings
        vm.NoOfParagraphs = "5";
        vm.ParagraphLength = "medium";
        vm.EnableLinks = true;
        vm.EnableUnorderedLists = false;
        vm.EnableOrderedLists = false;
        vm.EnableHeadings = true;
        vm.EnableStyle = true;
        vm.EnableAllCaps = false;

        $scope.GenerateLoripsum = function () {

            vm.Loading = true;
            var url = "/Umbraco/Loripsum/Loripsum/GenerateLoripsum";

            $http({
                method: "POST",
                url: url,
                data: {
                    NoOfParagraphs: vm.NoOfParagraphs,
                    ParagraphLength: vm.ParagraphLength,
                    EnableLinks: vm.EnableLinks,
                    EnableUnorderedLists: vm.EnableUnorderedLists,
                    EnableOrderedLists: vm.EnableOrderedLists,
                    EnableHeadings: vm.EnableHeadings,
                    EnableStyle: vm.EnableStyle,
                    EnableAllCaps: vm.EnableAllCaps
                },
            }).then(function successCallback(response) {
                vm.Loading = false;
                var data = angular.fromJson(response.data);
                vm.ResponseHtml = $sce.trustAsHtml(data.ResponseHtml);
            }, function errorCallback(response) {
                vm.Loading = false;
                vm.ResponseHtml = $sce.trustAsHtml("<h3>Sorry there was a generic error. If this continues to happen please notify support for a fix.</h3>");
            });

        };

        $scope.GenerateLoripsum();
    });
